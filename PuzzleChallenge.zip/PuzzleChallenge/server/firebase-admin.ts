import admin from "firebase-admin";

// Placeholder for future Firebase Admin implementation
// For now, we're using only client-side Firebase auth

const serviceAccount = null;

export { admin };